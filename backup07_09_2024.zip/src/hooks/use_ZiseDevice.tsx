import React from 'react'

export const use_ZiseDevice = () => {
  return {
    
  }
}


// import React from 'react'

// export const use_ZiseDevice = () => {
//     const[isMobile] = useMediaQuery({
//         maxWidth:700
//     })
//   return {
//     isMobile
//   }
// }
