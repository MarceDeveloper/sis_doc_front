export interface DTO_Reparticion{
    id_reparticion:       number
    nombre:               string
    estado:string          
    id_unidad:number
    codigo :number

    nivel:string
    unidad:string
    id_actividad:number
    actividad:string
    id_direccion:number
    direccion:string
    id_unidad_padre:number
}