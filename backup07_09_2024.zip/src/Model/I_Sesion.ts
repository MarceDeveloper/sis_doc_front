import { Usuario } from "./Usuario"

export interface I_Sesion{
    token:string
    usuario:Usuario
}