import swal from 'sweetalert2'
export {
    swal
}