export const console_DEV = (x:any)=>{
    console.log(x)
}