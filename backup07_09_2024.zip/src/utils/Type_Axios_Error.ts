import { AxiosError } from "axios";

export type Axios_Error_Api = AxiosError<{message:string}>