import React from 'react'
import { Link, useNavigate } from 'react-router-dom';
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Typography,
    Box,
    Button,
} from '@mui/material';
import { MenuItem, Select, InputLabel, FormControl, TextField } from '@mui/material';

import { Navbar } from '../../../../components/Navbar/Navbar';
import { MdDescription } from 'react-icons/md';
import { makeStyles } from '@mui/styles';
import { Colores } from '../../../../config/config_style';



const useStyles: any = makeStyles({
    tableContainer: {
        // margin: '20px',
        overflow: "auto",
        // maxWidth: 800
    },
    tableCell: {
        whiteSpace: "nowrap !important" as any,
        border: '1px solid #0c0c0c',
        padding: '0px !important',
        margin: 0,
        textAlign: 'center !important' as any,
    },
    tableHeaderCell: {
        whiteSpace: "nowrap !important" as any,
        border: '1px solid #030303',
        // padding: '8px',
        color: "#ffff !important",
        textAlign: 'center !important' as any,
        backgroundColor: Colores.color2
        // backgroundColor: '#f2f2f2',
    },
});


export const Reporte_Informe_Formato4 = () => {
    const classes = useStyles();

    return (

        <Box>
            <Typography my={5} textAlign={"center"}>Formato 4 RECOMENDACIONES EMITIDA POR LA CONTRALORÍA GENERAL DEL ESTADO POR AÑO Y DE TODOS LOS AÑOS</Typography>

            <Box sx={{display:"flex",justifyContent:"center"}}>
                <FormControl >
                    <InputLabel id="filter-type-label">Seleccionar Filtro</InputLabel>
                    <Select
                        size='small'
                        labelId="filter-type-label"
                        id="filter-type"
                        // value={""}
                        label="Seleccionar Filtro"
                    // onChange={handleChange}
                    >
                        <MenuItem value="allYears">Todos los años</MenuItem>
                        <MenuItem value="range">Por rango de años</MenuItem>
                    </Select>
                    <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-around" }}>
                        <TextField
                            size='small'
                            id="start-year"
                            label="Año de inicio"
                            type="number"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            variant="outlined"
                            margin="normal"
                        />

                        <TextField
                            size='small'
                            id="end-year"
                            label="Año de fin"
                            type="number"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            variant="outlined"
                            margin="normal"
                        />
                        <Button variant='contained'>Buscar</Button>

                    </Box>
                </FormControl>

            </Box>
            <TableContainer className={classes.tableContainer}>
                <Table>
                    <TableHead>
                        <TableRow >
                            <TableCell className={classes.tableHeaderCell}>RECOMENDACION</TableCell>
                            <TableCell className={classes.tableHeaderCell}>INFORME EMITIDO POR</TableCell>
                            <TableCell className={classes.tableHeaderCell}>JUSTIFICACIÓN DE NO ACEPTACIÓN</TableCell>
                        </TableRow>

                    </TableHead>
                    <TableBody>
                        <TableRow>
                            <TableCell className={classes.tableCell}>descripcion 12312312312</TableCell>
                            <TableCell className={classes.tableCell}>si</TableCell>
                            <TableCell className={classes.tableCell}>se justifica por motivos sociales</TableCell>

                        </TableRow>


                    </TableBody>
                </Table>
            </TableContainer>
        </Box>
    )
}
