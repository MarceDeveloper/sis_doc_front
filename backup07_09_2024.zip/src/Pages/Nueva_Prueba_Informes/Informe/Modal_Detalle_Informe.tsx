import React, { useState, useEffect } from 'react'
import {
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
} from '@mui/material';
import { makeStyles } from '@mui/styles';
import { Description } from '@mui/icons-material';
import moment from 'moment-timezone';


export interface Informe {
    estado: string;
    fecha_de_recepcion: string;
    id: number;
    informe_de_1: string;
    informe_de_2: string;
    informe_de_3: string;
    numero_informe: string;
    recomendacion: Recomendacion[];
    titulo: string;
}

export interface Recomendacion {
    antecedentes: string;
    comentario: string;
    descripcion: Descripcion[];
    estado: string;
    estado_recomendacion: string;
    id: number;
    id_informe: number;
    numero_de_recomendacion: string;
    titulo: string;
}

export interface Descripcion {
    aceptacion: boolean;
    estado: string;
    estado_descripcion: string;
    id: number;
    id_recomendacion: number;
    justificacion_no_aceptacion: string;
    plazo_de_implementacion: Date;
    tarea: Tarea[];
    texto: string;
    titulo: string;
}

export interface Tarea {
    acciones_tareas_mae: AccionesTareasMae[];
    id: number;
    id_descripcion: number;
    tarea_responsable: TareaResponsable[];
    texto: string;
}

export interface AccionesTareasMae {
    accion: string;
    id: number;
    id_tarea: number;
}

export interface Responsable {
    cargo: string;
    id: number;
    id_reparticion: number;
    nombre: string;
    reparticion: Reparticion;
    tarea_responsable: TareaResponsable[];
}

export interface TareaResponsable {
    acciones_tareas_reponsables: AccionesTareasReponsable[];
    id: number;
    id_responsable: number;
    id_tarea: number;
    responsable: Responsable;
}

export interface Reparticion {
    actividad: string;
    codigo: number;
    createdAt: Date;
    deletedAt: null;
    direccion: string;
    estado: string;
    id_actividad: number;
    id_direccion: number;
    id_reparticion: number;
    id_unidad: number;
    id_unidad_padre: number;
    id_user_create: number;
    id_user_delete: null;
    id_user_update: null;
    nivel: string;
    nombre: string;
    updatedAt: Date;
}

export interface AccionesTareasReponsable {
    accion: string;
    id: number;
    id_tarea_responsable: number;
}




const useStyles: any = makeStyles({
    tableContainer: {
        // margin: '20px',
        overflow: "auto",
        minHeight:"90vh"
        // maxWidth: 800
    },
    tableCell: {
        whiteSpace: "nowrap !important" as any,
        border: '1px solid #0c0c0c',
        padding: '0px !important',
        margin: 0,
        textAlign: 'center !important' as any,
    },
    tableHeaderCell: {
        whiteSpace: "nowrap !important" as any,
        border: '1px solid #030303',
        // padding: '8px',
        textAlign: 'center !important' as any,

        backgroundColor: '#f2f2f2',
    },
});


export const use_Modal_Detalle_Informe = () => {
    const [isOpen, setIsOpen] = useState(false);

    const [informe, setInforme] = useState<Informe | null>(null)
    const classes = useStyles();



    const Load = (informe: Informe) => {
        informe.recomendacion.forEach(recomendacion => {
            recomendacion.descripcion.forEach(desc => {
                desc.tarea.forEach(tarea => {
                    tarea.tarea_responsable.forEach(t_r => {
                        t_r.responsable?.tarea_responsable.forEach(x_t_r => {
                            x_t_r.acciones_tareas_reponsables?.forEach(a_t_r => {
                                console.log(a_t_r)
                            });
                        });
                    });
                });
            });
        });
        setInforme(informe)
    }

    const openModal = () => {
        setIsOpen(true);
    };

    const closeModal = () => {
        setIsOpen(false);
    };


    const get_responsables = (informe: Informe) => {
        const res = informe.recomendacion.flatMap((reco) => (
            reco.descripcion.flatMap((desc) => (
                desc.tarea.flatMap((tare) => (
                    tare.tarea_responsable.flatMap((t_r) => (
                        t_r.responsable
                    ))
                ))
            ))
        ))
        return res
    }



    const Modal_Content = () => {





        return (
            <>

                {
                    informe &&
                    <TableContainer className={classes.tableContainer}>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell className={classes.tableHeaderCell}>N° DE RECOMENDACIÓN</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>TITULO DE LA RECOMENDACIÓN</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>DESCRIPCION DE LA RECOMENDACIONX</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>ACEPTACIÓN</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>JUSTIFICACIÓN DE NO ACEPTACIÓN</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>PLAZO DE IMPLEMENTACIÓN</TableCell>
                                    <TableCell colSpan={1} className={classes.tableHeaderCell}>RESPONSABLES</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>TAREAS A DESARROLLAR</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>ACCIONES REALIZADAS POR  LA MAE</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>ACCIONES REALIZADAS POR LOS RESPONSABLES</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>ESTADO DE IMPLEMENTACIÓN DE RECOMENDACIÓN</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>ANTECEDENTE DE LA RECOMENDACIÓN</TableCell>
                                    <TableCell className={classes.tableHeaderCell}>COMENTARIO</TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell colSpan={6} className={classes.tableHeaderCell}></TableCell>
                                    <TableCell className={classes.tableHeaderCell}>NOMBRE Y APELLIDO / CARGO</TableCell>
                                    {/* <TableCell className={classes.tableHeaderCell}>CARGO</TableCell> */}
                                    <TableCell colSpan={7} className={classes.tableHeaderCell}></TableCell>
                                    {/* <TableCell colSpan={6} className={classes.tableHeaderCell}>CARGO</TableCell> */}

                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {
                                    informe.recomendacion.map((recomendacion) => (
                                        <TableRow>
                                            <TableCell className={classes.tableCell}>{recomendacion.numero_de_recomendacion}</TableCell>
                                            <TableCell className={classes.tableCell}>{recomendacion.titulo}</TableCell>
                                            <TableCell className={classes.tableCell}>
                                                {
                                                    recomendacion.descripcion.map((descipcion) => (
                                                        <TableRow>(id {descipcion.id}) {descipcion.titulo}</TableRow>
                                                    ))
                                                }
                                            </TableCell>
                                            <TableCell className={classes.tableCell}>
                                                {
                                                    recomendacion.descripcion.map((descipcion) => (
                                                        <TableRow>(id {descipcion.id}) {descipcion.aceptacion ? "si" : "no"} </TableRow>
                                                    ))
                                                }
                                            </TableCell>
                                            <TableCell className={classes.tableCell}>
                                                {
                                                    recomendacion.descripcion.map((descipcion) => (
                                                        <TableRow>(id {descipcion.id}) {descipcion.aceptacion ? descipcion.justificacion_no_aceptacion : ""} </TableRow>
                                                    ))
                                                }
                                            </TableCell>
                                            <TableCell className={classes.tableCell}>
                                                {
                                                    recomendacion.descripcion.map((descipcion) => (
                                                        <TableRow>(id {descipcion.id}) {moment(descipcion.plazo_de_implementacion).utc().format("DD-MM-YYYY")} </TableRow>
                                                    ))
                                                }
                                            </TableCell>
                                            <TableCell className={classes.tableCell}>
                                                {
                                                    get_responsables(informe).map((responsable) => (
                                                        <TableRow> {responsable?.nombre} / {responsable?.cargo} </TableRow>
                                                    ))
                                                }
                                            </TableCell>
                                            <TableCell className={classes.tableCell}>
                                                {
                                                    recomendacion.descripcion.map((desc) => (
                                                        desc.tarea.map((tarea) => (
                                                            <TableRow key={tarea.id}> {tarea.texto} </TableRow>
                                                        ))
                                                    ))
                                                }
                                            </TableCell>
                                            <TableCell className={classes.tableCell}>
                                                {
                                                    recomendacion.descripcion.map((desc) => (
                                                        desc.tarea.map((tarea) => (
                                                            tarea.acciones_tareas_mae.map((accion_mae) => (
                                                                <TableRow key={accion_mae.id}> {accion_mae.accion} </TableRow>
                                                            ))
                                                        ))
                                                    ))
                                                }
                                            </TableCell>
                                            <TableCell className={classes.tableCell}>
                                                {
                                                    recomendacion?.descripcion?.map((desc) => (
                                                        desc?.tarea?.map((tarea) => (
                                                            tarea?.tarea_responsable?.map((tarea_responable) => (
                                                                tarea_responable.responsable?.tarea_responsable.map((t_r) => (
                                                                    t_r.acciones_tareas_reponsables.map((accion_responsable)=>(
                                                                        <TableRow key={accion_responsable.id}> {tarea_responable.responsable.nombre} / {tarea_responable.responsable.cargo} / {accion_responsable.accion} </TableRow>
                                                                    ))
                                                                ))
                                                            ))
                                                        ))
                                                    ))
                                                }
                                            </TableCell>
                                            <TableCell className={classes.tableCell}>{recomendacion.estado}</TableCell>
                                            <TableCell className={classes.tableCell}>{recomendacion.antecedentes}</TableCell>
                                            <TableCell className={classes.tableCell}>{recomendacion.comentario}</TableCell>
                                            {/* <TableCell className={classes.tableCell}>dasd</TableCell> */}

                                        </TableRow>
                                    ))
                                }

                                {/* <TableRow>
                                    <TableCell className={classes.tableCell}>dasd</TableCell>
                                    <TableCell className={classes.tableCell}>dasd</TableCell>
                                    <TableCell className={classes.tableCell}>dasd</TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell className={classes.tableCell}>dasd</TableCell>
                                    <TableCell className={classes.tableCell}>dasd</TableCell>
                                    <TableCell className={classes.tableCell}>dasd</TableCell>
                                </TableRow> */}
                            </TableBody>
                        </Table>
                    </TableContainer>

                }
            </>
        )
    }
    return {
        Load,
        Modal_Content,
        isOpen,
        openModal,
        closeModal,
    }
}

// export const Tabla_Informe = ({ informe }: { informe: Informe }) => {
//     const classes = useStyles();
//     return (
//         <TableContainer className={classes.tableContainer}>
//             <Table>
//                 <TableHead>
//                     <TableRow>
//                         <TableCell className={classes.tableHeaderCell}>Info Informe</TableCell>
//                         <TableCell className={classes.tableHeaderCell}>Recomendaciones</TableCell>
//                     </TableRow>
//                 </TableHead>
//                 <TableBody>
//                     <TableRow>
//                         <TableCell className={classes.tableCell}>Info Informe</TableCell>
//                         <TableCell className={classes.tableCell}>
//                             {
//                                 informe.recomendacion.map((recomendacion) => (
//                                     <Tabla_Recomendacion recomendacion={recomendacion} />
//                                 ))
//                             }
//                         </TableCell>
//                     </TableRow>
//                 </TableBody>
//             </Table>
//         </TableContainer>
//     )
// }



// export const Tabla_Recomendacion = ({ recomendacion }: { recomendacion: Recomendacion }) => {
//     const classes = useStyles();
//     return (
//         <TableContainer component={Paper} className={classes.tableContainer}>
//             <Table>
//                 <TableHead>
//                     <TableRow>
//                         <TableCell className={classes.tableHeaderCell}>Info Recomendacion</TableCell>
//                         <TableCell className={classes.tableHeaderCell}>Descripciones</TableCell>
//                     </TableRow>
//                 </TableHead>
//                 <TableBody>
//                     <TableRow>
//                         <TableCell className={classes.tableCell}>Info Recomendacion</TableCell>
//                         <TableCell className={classes.tableCell}>
//                             dasdsad
//                             {/* <Tabla_Descipciones descripciones={recomendacion} /> */}
//                         </TableCell>
//                     </TableRow>
//                 </TableBody>
//             </Table>
//         </TableContainer>
//     )
// }


// export const Tabla_Descipciones = ({ descripciones }: { descripciones: Descripcion[] }) => {
//     const classes = useStyles();
//     return (
//         <TableContainer component={Paper} className={classes.tableContainer}>
//             <Table>
//                 <TableHead>
//                     <TableRow>
//                         <TableCell className={classes.tableHeaderCell}>Info Descripciones</TableCell>
//                         <TableCell className={classes.tableHeaderCell}>Tareas</TableCell>
//                     </TableRow>
//                 </TableHead>
//                 <TableBody>
//                     <TableRow>
//                         <TableCell className={classes.tableCell}>Info Descripciones</TableCell>
//                         <TableCell className={classes.tableCell}>
//                             <Tabla_Tareas />
//                         </TableCell>
//                     </TableRow>
//                 </TableBody>
//             </Table>
//         </TableContainer>
//     )
// }

// export const Tabla_Tareas = () => {
//     const classes = useStyles();
//     return (
//         <TableContainer component={Paper} className={classes.tableContainer}>
//             <Table>
//                 <TableHead>
//                     <TableRow>
//                         <TableCell className={classes.tableHeaderCell}>Info Tarea</TableCell>
//                         <TableCell className={classes.tableHeaderCell}>Acciones Mae</TableCell>
//                         <TableCell className={classes.tableHeaderCell}>Acciones Responsables</TableCell>

//                     </TableRow>
//                 </TableHead>
//                 <TableBody>
//                     <TableRow>
//                         <TableCell className={classes.tableCell}>Info Tarea</TableCell>
//                         <TableCell className={classes.tableCell}>
//                             <Tabla_Acciones_Mae />
//                         </TableCell>
//                         <TableCell className={classes.tableCell}>
//                             <Tabla_Acciones_Responsables />
//                         </TableCell>

//                     </TableRow>
//                 </TableBody>
//             </Table>
//         </TableContainer>
//     )
// }

// export const Tabla_Acciones_Mae = () => {
//     const classes = useStyles();
//     return (
//         <TableContainer component={Paper} className={classes.tableContainer}>
//             <Table>
//                 <TableHead>
//                     <TableRow>
//                         <TableCell className={classes.tableHeaderCell}>Info Acciones Mae</TableCell>
//                         <TableCell className={classes.tableHeaderCell}>Acciones</TableCell>
//                     </TableRow>
//                 </TableHead>
//                 <TableBody>
//                     <TableRow>
//                         <TableCell className={classes.tableCell}>Info Acciones Mae</TableCell>
//                         <TableCell className={classes.tableCell}>acciones</TableCell>
//                     </TableRow>
//                 </TableBody>
//             </Table>
//         </TableContainer>
//     )
// }
// export const Tabla_Acciones_Responsables = () => {
//     const classes = useStyles();
//     return (
//         <TableContainer component={Paper} className={classes.tableContainer}>
//             <Table>
//                 <TableHead>
//                     <TableRow>
//                         <TableCell className={classes.tableHeaderCell}>Info Acciones Responsables</TableCell>
//                         <TableCell className={classes.tableHeaderCell}>Acciones</TableCell>
//                     </TableRow>
//                 </TableHead>
//                 <TableBody>
//                     <TableRow>
//                         <TableCell className={classes.tableCell}>Info Acciones Mae</TableCell>
//                         <TableCell className={classes.tableCell}>
//                             dasd
//                         </TableCell>
//                     </TableRow>
//                 </TableBody>
//             </Table>
//         </TableContainer>
//     )
// }