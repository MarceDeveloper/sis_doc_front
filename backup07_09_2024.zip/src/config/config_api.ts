// export const api_base_url = `http://localhost:8080`
// export const api_base_url = `https://oym.uajms.edu.bo`

// export const api_base_url = `http://172.17.58.174:3000/`
export const api_base_url = `http://localhost:3000/`


// export const api_base_url = `http://172.16.202.74:3000/`


export const name_local_storage = "auditoria_app3121"

