export class Repository_Documento {
    constructor() {
        
    }
    get_all =()=>{
         
    }
}