export const Colores = {
    color1:"#184848",
    color2:"#006060",
    color3:"#007878",
    color4:"#a8c030",
    color5:"#e6e8e3",
    backdrop:"#65727a",
    Drawer_Head:"#007878",
    Drawer_Box:"#007878",
    Navbar:"#184848",
    error:"#e34d4d"
}