export const api_base_url = `http://localhost:3000`
// export const api_base_url = `http://172.16.202.85:3000/`
// export const api_base_url = `http://172.17.58.238:3000/`


export const name_local_storage = "auditoria_app3121"
