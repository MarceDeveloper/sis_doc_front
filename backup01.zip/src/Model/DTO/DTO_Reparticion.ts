interface DTO_Reparticion{
    id_reparticion:       number
    nombre:               string
    estado:string          
    id_unidad:number
    codigo :number
}