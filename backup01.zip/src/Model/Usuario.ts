export interface Usuario {
    id_usuario: number;
    nombre_usuario: string;
    nombre: string;
    estado: string;
    contrasena:string
}