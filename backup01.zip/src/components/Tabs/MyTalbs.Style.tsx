import styled from "styled-components";

export const ButonTab = styled.div`
    height: 100%;
    background-color: #1aa1ae;
    display: flex;
    align-items: center;
`