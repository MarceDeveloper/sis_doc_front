import { Box, Center, Container , HStack, Text} from 'native-base'
import * as s from './MyTalbs.Style'

export const MyTabs = () => {
  return (
    <h1>my tabs</h1>
    // <Center backgroundColor={'primary.200'} flexDirection={'row'} w={"100%"}style={{height:40}} >
    //     <s.ButonTab>
    //         <Text color={'white'}>tab 1</Text>
    //     </s.ButonTab>
    //     <s.ButonTab>
    //         <Text color={'white'}>tab 2</Text>
    //     </s.ButonTab>
    // </Center>
  )
}
